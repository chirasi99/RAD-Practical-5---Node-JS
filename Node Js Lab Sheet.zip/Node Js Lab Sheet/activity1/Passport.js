
const express = require('express')
const path = require('path')
const passport = require('passport')
const localStrategy = require('passport-local').Strategy
const session = require('express-session')

const users = [
    {   
        email: 'chirasi@gmail.com', 
        password: '456789'
    },
    {
        email: 'amaya@gmail.com', 
        password: '123456'
    },
]

const app = express()

app.use(express.urlencoded({ extended: false }))

passport.use(new localStrategy({usernameField: 'email'}, function verify(email, password, cb) {
    
    const user = users.find(user => user.email === email)

    if (user == null) {
        return cb(null, false)
    }

    if (user.password != password) {
        return cb(null, false)
    }
    else{
        return cb(null, user)
    }
}))

passport.serializeUser((user, cb) => cb(null, user.email))
passport.deserializeUser((email, cb) => cb(null, users.find(user => user.email === email)))

app.use(session({
    secret: 'SECRET_KEY',
    resave: false,
    saveUninitialized: false
}))

app.use(passport.initialize())
app.use(passport.session())

app.post('/', passport.authenticate('local', {
    successRedirect: '/home',
    failureRedirect: '/'
}))

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, 'login.html'))
})

app.get("/home", (req, res) => {
    
    req.session.count += 1
    if(isNaN(req.session.count)){
        req.session.count = 1
        res.send("Welcome to the home page first time!")
    }
    else{
        res.send(`You visited this page ${req.session.count} times!`)
    }
})

app.listen(5500, ()=> {
    console.log("server is running on port 5500...")
})