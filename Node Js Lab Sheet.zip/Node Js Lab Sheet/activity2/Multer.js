const express = require('express')
const path = require('path')
const multer = require('multer')

const app = express()

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'images')
    },
    filename: (req, file, cb) => {
        console.log(file)
        cb(null, Date.now() + path.extname(file.originalname))
    }
})

const upload = multer({ storage: storage })

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html')
})

app.post('/upload', upload.single("photo"), (req, res) =>{
    res.send(`file uploaded!`)
})

app.listen(5600, () => {
  console.log('Example app listening on port 5600...')
})